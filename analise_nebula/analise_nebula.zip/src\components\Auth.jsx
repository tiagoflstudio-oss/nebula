import React, { useState } from 'react';
import { supabase } from '../lib/supabaseClient';

const Auth = ({ onClose }) => {
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [isSignUp, setIsSignUp] = useState(false);
  const [error, setError] = useState(null);

  const [showSuccess, setShowSuccess] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const handleAuth = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      if (isSignUp) {
        const { error } = await supabase.auth.signUp({ 
          email, 
          password,
          options: {
            data: { full_name: fullName }
          }
        });
        if (error) throw error;
        setShowSuccess(true);
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-overlay">
      <div className="auth-nebula-glow"></div>
      <div className="auth-card glass fade-in">
        {onClose && (
          <button className="auth-close-btn" onClick={onClose} title="Fechar">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" width="20" height="20">
              <path d="M18 6L6 18M6 6l12 12" />
            </svg>
          </button>
        )}
        <div className="auth-header">
          <div className="auth-logo">
            <h2>Nebula</h2>
          </div>
          <p>{isSignUp ? 'Crie sua conta no ecossistema' : 'Bem-vindo de volta ao futuro'}</p>
        </div>

        {showSuccess ? (
          <div className="auth-success-view fade-in">
            <div className="success-icon-container">
              <div className="success-pulse"></div>
              <span className="material-symbols-outlined">mark_email_read</span>
            </div>
            <h3>Quase lá!</h3>
            <p>Enviamos um link de confirmação para:</p>
            <div className="success-email-badge">{email}</div>
            <p className="success-note">
              Por favor, verifique sua caixa de entrada (e spam) para ativar sua conta no ecossistema.
            </p>
            <button className="btn-auth-premium" onClick={() => setShowSuccess(false)}>
              Voltar ao Login
            </button>
          </div>
        ) : (
          <form className="auth-form" onSubmit={handleAuth}>
            {isSignUp && (
              <div className="auth-field">
                <label>Nome Completo</label>
                <div className="input-with-icon">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>
                  </svg>
                  <input
                    type="text"
                    placeholder="Seu nome"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    required={isSignUp}
                  />
                </div>
              </div>
            )}

            <div className="auth-field">
              <label>E-mail Corporativo</label>
              <div className="input-with-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/>
                </svg>
                <input
                  type="email"
                  placeholder="seu@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="auth-field">
              <label>Sua Senha</label>
              <div className="input-with-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                </svg>
                <input
                  type={showPassword ? "text" : "password"}
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
                <button 
                  type="button"
                  className="btn-eye" 
                  onClick={() => setShowPassword(!showPassword)}
                  title={showPassword ? "Esconder senha" : "Mostrar senha"}
                >
                  <span className="material-symbols-outlined" style={{ fontSize: '20px' }}>
                    {showPassword ? 'visibility_off' : 'visibility'}
                  </span>
                </button>
              </div>
            </div>

            {error && <div className="auth-error-message">{error}</div>}

            <button type="submit" className="btn-auth-premium" disabled={loading}>
              {loading ? (
                <span className="loader-dots">
                  <span></span><span></span><span></span>
                </span>
              ) : (
                <>{isSignUp ? 'Finalizar Cadastro' : 'Entrar no Sistema'}</>
              )}
            </button>
          </form>
        )}

        <div className="auth-footer">
          <p>{isSignUp ? 'Já possui acesso?' : 'Ainda não tem uma conta?'}</p>
          <button className="btn-toggle-auth" onClick={() => setIsSignUp(!isSignUp)}>
            {isSignUp ? 'Faça login aqui' : 'Solicite acesso agora'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Auth;
